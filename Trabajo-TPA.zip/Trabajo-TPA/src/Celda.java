/**
 * Práctica
 * Grupo de TPA M21
 * Equipo de trabajo:
 * Javier Rafael Cubas Alonso (22132785)
 * Christian Jonathan Yang Gonzalez (22133089)
 * Fecha creación 18-03-2023
 * Fecha última 31-03-2023
 * Versión 1.0
 */
/**
 * Clase que representa una celda de una tabla hash.
 * @param <Valor> tipo de objeto almacenado en la celda.
 */
public class Celda<Valor> {
    /**
     * Clave asociada a la celda.
     */
    private int clave;
    /**
     * Valor almacenado en la celda.
     */
    private Valor valor;
    /**
     * Estado de la celda.
     */
    private int estado;
    /**
     * Crea una nueva instancia de la clase con valores predeterminados.
     */
    public Celda(){
        this.clave = 0;
        this.valor = null;
        this.estado = 0;
    }
    /**
     * Crea una nueva instancia de la clase con la clave y el valor especificados.
     * @param clave la clave asociada a la celda.
     * @param valor el valor almacenado en la celda.
     */
    public Celda(int clave, Valor valor){
        this.clave = clave;
        this.valor = valor;
    }
    /**
     * Establece el estado de la celda.
     * @param estado el nuevo estado de la celda.
     * @return true si se estableció el estado correctamente, false en caso contrario.
     */
    public boolean setEstado(int estado) {
        this.estado = estado;
        return true;
    }
    /**
     * Obtiene el estado actual de la celda.
     * @return el estado actual de la celda.
     */
    public int getEstado() {
        return estado;
    }
    /**
     * Establece la clave asociada a la celda.
     * @param clave la nueva clave de la celda.
     */
    public void setClave(int clave) {
        this.clave = clave;
    }
    /**
     * Obtiene la clave asociada a la celda.
     * @return la clave asociada a la celda.
     */
    public int getClave() {
        return clave;
    }
    /**
     * Establece el valor almacenado en la celda.
     * @param valor el nuevo valor almacenado en la celda.
     */
    public void setValor(Valor valor) {
        this.valor = valor;
    }
    /**
     * Obtiene el valor almacenado en la celda.
     * @return el valor almacenado en la celda.
     */
    public Valor getValor() {
        return valor;
    }
    /**
     * Compara la celda actual con otra celda para determinar si son iguales.
     * @return true si las celdas son iguales, false en caso contrario.
     */
    public boolean equals(){
        return true;
    }
}

/**
 * Práctica
 * Grupo de TPA M21
 * Equipo de trabajo:
 * Javier Rafael Cubas Alonso (22132785)
 * Christian Jonathan Yang Gonzalez (22133089)
 * Fecha creación 18-03-2023
 * Fecha última 31-03-2023
 * Versión 1.0
 */
/**
 * Clase Main que contiene el método principal de ejecución del programa.
 */
public class Main {
    /**
     * Método principal de ejecución del programa. Imprime "Hello world!" en la consola.
     * @param args Arreglo de argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
/**
 * Práctica
 * Grupo de TPA M21
 * Equipo de trabajo:
 * Javier Rafael Cubas Alonso (22132785)
 * Christian Jonathan Yang Gonzalez (22133089)
 * Fecha creación 18-03-2023
 * Fecha última 31-03-2023
 * Versión 1.0
 */
/**
 * Clase que implementa una tabla hash genérica.
 * @param <Valor> tipo de datos a almacenar.
 */
public class Hash<Valor> {
    /**
     * Clave contenedor a la celda.
     */
    private Celda<Valor>[] contenedor;
    /**
     * Clave numElementos tipo entero.
     */
    private int numElementos;
    /**
     * Clave alfaMaximo tipo float.
     */
    private float alfaMaximo;
    /**
     * Constructor por defecto.
     */
    public void Hash(){
        this.contenedor = null;
        this.numElementos = 7;
        this.alfaMaximo = 80;
    }
    /**
     * Constructor con parámetro.
     * @param numElementos número de celdas de la tabla.
     */
    public void Hash(int numElementos){
        this.numElementos = numElementos;
    }
    /**
     * Constructor con dos parámetros.
     * @param numElementos número de celdas de la tabla.
     * @param alfaMaximo factor de carga máximo.
     */
    public void Hash(int numElementos, float alfaMaximo) {
        this.numElementos = numElementos;
        this.alfaMaximo = alfaMaximo;
    }
    /**
     * Método que inserta un valor en la tabla hash.
     * @param clave clave del valor a insertar.
     * @param v valor a insertar.
     */
    public void insertar(int clave, Valor v){
    }
    /**
     * Método que elimina un valor de la tabla hash.
     * @param clave clave del valor a eliminar.
     * @return true si se ha eliminado el valor, false en caso contrario.
     */
    public boolean borrar(int clave){
        return true;
    }
    /**
     * Método que devuelve el valor asociado a una clave en la tabla hash.
     * @param clave clave del valor a buscar.
     * @return valor asociado a la clave.
     */
    public Valor get(int clave){
        return null;
    }
    /**
     * Método que indica si la tabla hash está vacía.
     * @return true si la tabla está vacía, false en caso contrario.
     */
    public boolean esVacia(){
        return true;
    }
    /**
     * Método que devuelve el factor de carga máximo de la tabla hash.
     * @return factor de carga máximo.
     */
    public float getAlfaMax() {
        return alfaMaximo;
    }
    /**
     * Método que establece el factor de carga máximo de la tabla hash.
     * @param alfaMaximo factor de carga máximo.
     */
    public void setAlfaMax(float alfaMaximo) {
        this.alfaMaximo = alfaMaximo;
    }
    /**
     * Método que devuelve el número de celdas de la tabla hash.
     * @return número de celdas de la tabla.
     */
    public int getNumElementos() {
        return numElementos;
    }
    /**
     * Método que indica si hay colisión en una celda de la tabla hash.
     * @param index índice de la celda.
     * @return true si hay colisión, false en caso contrario.
     */
    private boolean hayColision(int index){
        return true;
    }
    /**
     * Método que calcula el valor hash de una clave en función del número de colisiones.
     * @param clave clave a hashear.
     * @param colisiones número de colisiones.
     * @return valor hash de la clave.
     */
    private int funcionHash(int clave, int colisiones){
        return  hash1(clave) + hash2(clave, colisiones);
    }
    /**
     * Retorna el hash de la clave utilizando la operación módulo.
     *
     * @param clave la clave a la que se le calculará el hash.
     * @return el hash de la clave.
     */
    private int hash1(int clave){
        return clave % this.numElementos;
    }
    /**
     * Retorna el segundo hash de la clave utilizando la fórmula
     * colisiones * (7 - (clave % 7)).
     *
     * @param clave la clave a la que se le calculará el segundo hash.
     * @param colisiones el número de colisiones que ha tenido la clave.
     * @return el segundo hash de la clave.
     */
    private int hash2(int clave, int colisiones){
        return colisiones * (7-(clave % 7));
    }
    /**
     * Redimensiona el contenedor de la tabla de hash. Esta operación se
     * realiza cuando se alcanza el valor de alfa máximo.
     */
    private void redimensionar(){

    }
    /**
     * Retorna verdadero si el número pasado como parámetro es primo;
     * falso en caso contrario.
     *
     * @param num el número a evaluar.
     * @return verdadero si el número es primo; falso en caso contrario.
     */
    private boolean esPrimo(int num){
        return false;
    }
    /**
     * Retorna el siguiente número primo mayor al número pasado como
     * parámetro.
     *
     * @param num el número a partir del cual se buscará el siguiente primo.
     * @return el siguiente número primo mayor al número pasado como parámetro.
     */
    private int siguientePrimo(int num){
        return 0;
    }
    /**
     * Retorna una cadena que representa el objeto Hash. La cadena contiene
     * el valor de los atributos contenedor, numElementos y alfaMaximo.
     *
     * @return una cadena que representa el objeto Hash.
     */
    public String toString() {
        return "Hash{" +
                "contenedor=" + contenedor +
                ", numElementos=" + numElementos +
                ", alfaMaximo=" + alfaMaximo +
                "}";
    }
}